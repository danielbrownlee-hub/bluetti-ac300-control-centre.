package com.advanturehub.bluetti

import android.app.Activity
import android.os.Bundle
import android.graphics.Color
import android.graphics.Typeface
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.widget.*
import org.json.JSONArray
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL
import java.security.MessageDigest
import java.security.SecureRandom
import java.util.concurrent.Executors
import javax.crypto.Cipher
import javax.crypto.KeyGenerator
import javax.crypto.SecretKey
import javax.crypto.spec.GCMParameterSpec
import android.security.keystore.KeyGenParameterSpec
import android.security.keystore.KeyProperties
import android.util.Base64

class MainActivity : Activity() {
    private val bg = Color.rgb(16, 27, 32)
    private val panel = Color.rgb(27, 45, 52)
    private val lime = Color.rgb(139, 224, 82)
    private val pale = Color.rgb(232, 241, 243)
    private val muted = Color.rgb(166, 185, 190)
    private val pool = Executors.newSingleThreadExecutor()
    private lateinit var appKey: EditText
    private lateinit var appSecret: EditText
    private lateinit var status: TextView
    private lateinit var deviceSpinner: Spinner
    private lateinit var details: TextView
    private var devices = JSONArray()
    private var selectedSn = ""

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        buildUi()
        loadSavedCredentials()
    }

    private fun buildUi() {
        val scroll = ScrollView(this).apply { setBackgroundColor(bg); isFillViewport = true }
        val root = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(18), dp(18), dp(18), dp(30)) }
        scroll.addView(root)
        val title = TextView(this).apply { text = "BLUETTI"; textSize = 30f; setTextColor(lime); typeface = Typeface.DEFAULT_BOLD }
        root.addView(title)
        root.addView(TextView(this).apply { text = "AC300 + B300K CONTROL CENTRE"; textSize = 13f; setTextColor(muted) })
        root.addView(gap(18))

        card(root, "01  ·  API CONNECTION")
        addView(label("App Key"))
        appKey = edit("Enter BLUETTI App Key", false); addView(appKey)
        addView(label("App Secret"))
        appSecret = edit("Enter BLUETTI App Secret", true); addView(appSecret)
        addView(button("SAVE CREDENTIALS SECURELY", lime) { saveCredentials() })
        addView(button("CONNECT TO BLUETTI", pale) { connect() })
        status = TextView(this).apply { text = "Credentials are stored encrypted on this device only."; setTextColor(muted); textSize = 13f; setPadding(0, dp(10), 0, dp(4)) }
        addView(status)

        root.addView(gap(18)); card(root, "02  ·  YOUR DEVICES")
        deviceSpinner = Spinner(this); addView(deviceSpinner)
        addView(button("REFRESH DEVICE LIST", lime) { connect() })
        addView(button("LOAD LAST 24 HOURS TELEMETRY", pale) { loadHistory() })
        details = TextView(this).apply { text = "Connect to load your authorised devices."; textSize = 14f; setTextColor(muted); setPadding(0, dp(12), 0, dp(8)); typeface = Typeface.MONOSPACE }
        addView(details)

        root.addView(gap(18)); card(root, "03  ·  OUTPUT CONTROLS")
        addView(TextView(this).apply {
            text = "The BLUETTI OpenAPI document confirms generic device setup endpoints, but does not publish the AC300 function codes or required values for AC output, DC output or main power. Controls are intentionally locked until BLUETTI supplies those exact codes. This prevents sending an unsafe or incorrect command."
            setTextColor(muted); textSize = 14f; setPadding(0, dp(8), 0, dp(8))
        })
        addView(button("WHAT COMMAND DETAILS DO I NEED?", lime) {
            showMessage("Ask BLUETTI for the AC300 functionCode and exact setValue payload for: AC output ON/OFF, DC output ON/OFF, and main unit power ON/OFF. Also ask whether the commands are supported for your device firmware.")
        })
        addView(gap(16))
        addView(TextView(this).apply { text = "Direct Android API connection · No Cloudflare · No external server"; setTextColor(muted); textSize = 12f; gravity = Gravity.CENTER; setPadding(0, dp(10), 0, 0) })
        setContentView(scroll)
    }

    private fun card(parent: LinearLayout, heading: String) {
        val box = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(16), dp(14), dp(16), dp(16)); setBackgroundColor(panel) }
        val params = LinearLayout.LayoutParams(-1, -2).apply { bottomMargin = dp(10) }
        parent.addView(box, params)
        box.addView(TextView(this).apply { text = heading; textSize = 18f; typeface = Typeface.DEFAULT_BOLD; setTextColor(pale); setPadding(0, 0, 0, dp(8)) })
        // Keep following controls in the same vertical parent for a simple, dependency-free layout.
        box.tag = heading
        activeCard = box
    }
    private var activeCard: LinearLayout? = null
    private fun label(s: String) = TextView(this).apply { text = s; setTextColor(muted); textSize = 14f; setPadding(0, dp(8), 0, dp(4)) }
    private fun edit(hint: String, secret: Boolean): EditText = EditText(this).apply {
        this.hint = hint; setTextColor(pale); setHintTextColor(muted); textSize = 15f
        setSingleLine(true); setPadding(dp(12), dp(8), dp(12), dp(8)); setBackgroundColor(Color.rgb(12, 23, 28))
        if (secret) inputType = android.text.InputType.TYPE_CLASS_TEXT or android.text.InputType.TYPE_TEXT_VARIATION_PASSWORD
    }
    private fun button(text: String, color: Int, action: () -> Unit) = Button(this).apply {
        this.text = text; setTextColor(if (color == lime) Color.rgb(16, 27, 20) else Color.rgb(16, 27, 32)); setBackgroundTintList(android.content.res.ColorStateList.valueOf(color)); textSize = 13f
        setOnClickListener { action() }
    }
    private fun gap(n: Int) = View(this).apply { layoutParams = LinearLayout.LayoutParams(1, dp(n)) }
    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    // Add all controls to the currently opened card.
    private fun addView(view: View) { activeCard?.addView(view) }

    private fun saveCredentials() {
        try {
            val k = appKey.text.toString().trim(); val s = appSecret.text.toString().trim()
            require(k.isNotBlank() && s.isNotBlank()) { "Enter both credentials first." }
            val prefs = getSharedPreferences("secure", MODE_PRIVATE)
            prefs.edit().putString("key", encrypt(k)).putString("secret", encrypt(s)).apply()
            status.text = "Credentials saved encrypted on this device."
        } catch (e: Exception) { status.text = e.message ?: "Could not save credentials." }
    }
    private fun loadSavedCredentials() {
        try {
            val p = getSharedPreferences("secure", MODE_PRIVATE)
            p.getString("key", null)?.let { appKey.setText(decrypt(it)) }
            p.getString("secret", null)?.let { appSecret.setText(decrypt(it)) }
        } catch (_: Exception) { status.text = "Saved credentials could not be decrypted. Please re-enter them." }
    }
    private fun getKey(): SecretKey {
        val ks = java.security.KeyStore.getInstance("AndroidKeyStore").apply { load(null) }
        (ks.getKey("BluettiCredentialKey", null) as? SecretKey)?.let { return it }
        val gen = KeyGenerator.getInstance(KeyProperties.KEY_ALGORITHM_AES, "AndroidKeyStore")
        gen.init(KeyGenParameterSpec.Builder("BluettiCredentialKey", KeyProperties.PURPOSE_ENCRYPT or KeyProperties.PURPOSE_DECRYPT).setBlockModes(KeyProperties.BLOCK_MODE_GCM).setEncryptionPaddings(KeyProperties.ENCRYPTION_PADDING_NONE).build())
        return gen.generateKey()
    }
    private fun encrypt(value: String): String {
        val c = Cipher.getInstance("AES/GCM/NoPadding"); c.init(Cipher.ENCRYPT_MODE, getKey())
        val bytes = c.iv + c.doFinal(value.toByteArray(Charsets.UTF_8)); return Base64.encodeToString(bytes, Base64.NO_WRAP)
    }
    private fun decrypt(value: String): String {
        val all = Base64.decode(value, Base64.NO_WRAP); val iv = all.copyOfRange(0, 12); val data = all.copyOfRange(12, all.size)
        val c = Cipher.getInstance("AES/GCM/NoPadding"); c.init(Cipher.DECRYPT_MODE, getKey(), GCMParameterSpec(128, iv)); return String(c.doFinal(data), Charsets.UTF_8)
    }

    private fun connect() {
        val key = appKey.text.toString().trim(); val secret = appSecret.text.toString().trim()
        if (key.isBlank() || secret.isBlank()) { status.text = "Enter your App Key and App Secret first."; return }
        status.text = "Connecting securely to BLUETTI…"
        pool.execute {
            try {
                val response = api("/bluiotdata/device/telemetry/v1/userTelemetryDeviceList", JSONObject().put("pageNo", 1).put("pageSize", 50), key, secret)
                val data = response.optJSONObject("data") ?: JSONObject()
                val list = data.optJSONArray("records") ?: data.optJSONArray("list") ?: data.optJSONArray("rows") ?: JSONArray()
                devices = list
                val names = ArrayList<String>(); val sns = ArrayList<String>()
                for (i in 0 until list.length()) {
                    val d = list.optJSONObject(i) ?: continue
                    val sn = d.optString("deviceSn"); if (sn.isNotBlank()) { sns.add(sn); names.add(d.optString("deviceRemarkNames").ifBlank { d.optString("deviceName").ifBlank { "BLUETTI device" } } + "  ·  " + sn) }
                }
                runOnUiThread {
                    if (sns.isEmpty()) { status.text = "API connected, but no devices were found in the returned list. Response: ${response.toString().take(500)}" }
                    else {
                        selectedSn = sns[0]
                        deviceSpinner.adapter = ArrayAdapter(this, android.R.layout.simple_spinner_dropdown_item, names)
                        deviceSpinner.onItemSelectedListener = object : android.widget.AdapterView.OnItemSelectedListener {
                            override fun onNothingSelected(parent: android.widget.AdapterView<*>?) {}
                            override fun onItemSelected(parent: android.widget.AdapterView<*>?, view: View?, position: Int, id: Long) { selectedSn = sns.getOrElse(position) { "" } }
                        }
                        status.text = "Connected. ${sns.size} authorised device(s) found."
                        details.text = "Selected device serial:\n${selectedSn}\n\nChoose LOAD LAST 24 HOURS TELEMETRY to request reported history."
                    }
                }
            } catch (e: Exception) { runOnUiThread { status.text = "Connection failed: ${e.message}" } }
        }
    }

    private fun loadHistory() {
        val key = appKey.text.toString().trim(); val secret = appSecret.text.toString().trim(); val sn = selectedSn
        if (key.isBlank() || secret.isBlank() || sn.isBlank()) { status.text = "Connect and select a device first."; return }
        status.text = "Loading reported telemetry…"
        pool.execute {
            try {
                val now = System.currentTimeMillis()
                val body = JSONObject().put("deviceSn", sn).put("beginTimestamp", now - 86_400_000L).put("endTimestamp", now).put("pageNo", 1).put("pageSize", 100)
                val result = api("/bluiotdata/device/telemetry/v1/telemetryDeviceReportedData", body, key, secret)
                runOnUiThread { details.text = result.toString(2); status.text = "Telemetry history response received. This endpoint returns reported history, not guaranteed live readings." }
            } catch (e: Exception) { runOnUiThread { status.text = "Telemetry request failed: ${e.message}" } }
        }
    }

    private fun api(path: String, body: JSONObject, key: String, secret: String): JSONObject {
        val timestamp = (System.currentTimeMillis() / 1000L).toString()
        val random = ByteArray(16).also { SecureRandom().nextBytes(it) }
        val nonce = random.joinToString("") { "%02X".format(it) }
        val source = "appKey=$key&appSecret=$secret&nonceStr=$nonce&timeStamp=$timestamp"
        val signature = MessageDigest.getInstance("SHA-256").digest(source.toByteArray(Charsets.UTF_8)).joinToString("") { "%02X".format(it) }
        val conn = (URL("https://open.bluetti.com/open$path").openConnection() as HttpURLConnection)
        conn.requestMethod = "POST"; conn.connectTimeout = 20000; conn.readTimeout = 25000; conn.doOutput = true
        conn.setRequestProperty("Content-Type", "application/json; charset=utf-8")
        conn.setRequestProperty("x-app-key", key); conn.setRequestProperty("Authorization", signature)
        conn.setRequestProperty("Date", timestamp); conn.setRequestProperty("ETag", nonce)
        conn.outputStream.use { it.write(body.toString().toByteArray(Charsets.UTF_8)) }
        val code = conn.responseCode
        val stream = if (code in 200..299) conn.inputStream else conn.errorStream
        val raw = stream?.bufferedReader()?.use { it.readText() } ?: ""
        conn.disconnect()
        val json = try { JSONObject(raw) } catch (_: Exception) { throw Exception("HTTP $code: ${raw.take(500)}") }
        val apiCode = if (json.has("msgCode")) json.optInt("msgCode", 0) else json.optInt("code", 0)
        if (code !in 200..299 || (apiCode != 0 && apiCode != 200)) throw Exception("HTTP $code / API $apiCode: ${json.optString("message", json.optString("msg", raw)).take(500)}")
        return json
    }
    private fun showMessage(message: String) = android.app.AlertDialog.Builder(this).setTitle("BLUETTI command information").setMessage(message).setPositiveButton("OK", null).show()
    override fun onDestroy() { super.onDestroy(); pool.shutdown() }
}
