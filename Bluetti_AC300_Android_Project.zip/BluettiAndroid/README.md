# BLUETTI AC300 + B300K Control Centre (Android)

A native Android client for the BLUETTI Open Platform. It makes requests from Android's networking stack, so the browser's restricted `Date` header is not involved. No Cloudflare Worker, web server, or paid hosting is used.

## What is included

- App Key / App Secret entry.
- Local encrypted credential storage using Android Keystore (AES-GCM).
- Signed BLUETTI API requests using the documented SHA-256 signature format and `Date`, `ETag`, `Authorization`, and `x-app-key` headers.
- Authorised device list request.
- Last-24-hours reported telemetry request.
- An explicit explanation of why output controls are locked pending the AC300 command catalogue.
- GitHub Actions workflow that builds a debug APK and publishes it as a downloadable workflow artifact.

## Important API limitations

The supplied BLUETTI OpenAPI document documents the generic `telemetryDeviceSetUp` and `telemetryDeviceAdvanceSetUp` endpoints with `deviceSn`, `functionCode`, and `setValue`. It does **not** provide the AC300-specific function-code catalogue or exact values for AC output, DC output, or main-unit power. This app therefore does not send guessed power commands.

The `telemetryDeviceReportedData` endpoint is a reported-data/history endpoint. It should not be mistaken for a guaranteed live telemetry stream. The exact response fields can vary by device and are displayed as returned.

## Build APK for free using GitHub from your phone

1. Create a new **public or private** GitHub repository. Name it `bluetti-ac300-control-centre`.
2. Upload the contents of this project into the repository, keeping the `.github/workflows/android.yml` path intact. If the GitHub Android app does not offer folder upload, open `https://github.com` in Chrome, switch to **Desktop site**, open the repository, choose **Add file → Upload files**, and upload the project files/folders from the ZIP after extracting it. The GitHub app itself is not an Android build environment.
3. Commit the files to the `main` branch.
4. Open the repository's **Actions** tab. Select **Build BLUETTI Android APK** and press **Run workflow** (or let the first push start it automatically).
5. Wait for the run to finish successfully. Open the completed run and download the artifact named `Bluetti-AC300-Control-Centre-APK`.
6. Extract the downloaded artifact ZIP. Install `app-debug.apk` on your Samsung. Android may ask you to allow installation from that source; only enable it for the app you used to download the APK.

## API credentials

Enter the App Key and App Secret from your BLUETTI Open Platform application. The app stores them encrypted locally with an Android Keystore key. They are not uploaded to GitHub or any server. Do not commit credentials into this project.

## Build locally (optional)

Requires JDK 17, Gradle 8.9, and Android SDK Platform 35. Run:

```bash
gradle assembleDebug
```

APK output: `app/build/outputs/apk/debug/app-debug.apk`.
